package com.example.klu.myapplication1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity1 extends AppCompatActivity {
    EditText number1;
    EditText number2;
    Button Add_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);

        // by ID we can use each component which id is assign in xml file
        number1 = (EditText) findViewById(R.id.editText7);
        number2 = (EditText) findViewById(R.id.editText8);
        Add_button = (Button) findViewById(R.id.button6);

        // Add_button add clicklistener
        Add_button.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                // num1 or num2 double type
                // get data which is in edittext, convert it to string
                // using parse Double convert it to Double type
                int a, b;
                a = Integer.parseInt(number1.getText().toString());
                b = Integer.parseInt(number2.getText().toString());
                Toast.makeText(MainActivity1.this, "" + (a + b), Toast.LENGTH_SHORT).show();
            }
        });
    }
}