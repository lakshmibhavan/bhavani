package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {
    ImageButton b;
    ImageButton b2;
    ImageButton b3;
    ImageButton b4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b = (ImageButton)findViewById(R.id.imageButton4);
        b2 = (ImageButton)findViewById(R.id.imageButton5);
        b3 = (ImageButton)findViewById(R.id.imageButton6);
        b4 = (ImageButton)findViewById(R.id.imageButton7);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent i = new Intent(getBaseContext(),Main2Activity.class);
                startActivity(i);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getBaseContext(),Main3Activity.class);
                startActivity(i);

            }
        });
    b3.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent i = new Intent(getBaseContext(),Main4Activity.class);
            startActivity(i);
        }
    });
    b4.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent i = new Intent(getBaseContext(),Main5Activity.class);
            startActivity(i);
        }
    });
    }


}
