package com.example.ex3b;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;


public class HomePage extends AppCompatActivity {
    ImageButton b;
    ImageButton b2;
    ImageButton b3;
    ImageButton b4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        b = (ImageButton)findViewById(R.id.imageButton22);
        b2 = (ImageButton)findViewById(R.id.imageButton23);
        b3 = (ImageButton)findViewById(R.id.imageButton24);
        b4 = (ImageButton)findViewById(R.id.imageButton20);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent i = new Intent(getBaseContext(),Main2Activity.class);
                startActivity(i);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getBaseContext(),Main3Activity.class);
                startActivity(i);

            }
        });




        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getBaseContext(),Main4Activity.class);
                startActivity(i);
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getBaseContext(),Main5Activity.class);
                startActivity(i);
            }
        });
    }
}
