package com.example.homepage;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class Main2Activity extends AppCompatActivity {
    ImageButton b1;
    ImageButton b2;
    ImageButton b3;
    ImageButton b4;
    ImageButton b5;
    ImageButton b6;
    ImageButton b7;
    ImageButton b8;
    ImageButton b9;
    ImageButton b10;
    ImageButton b11;
    ImageButton b12;
    ImageButton b13;
    ImageButton b14;
    ImageButton b15;
    ImageButton b16;
    ImageButton b17;
    ImageButton b18;
    ImageButton b19;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main2);

                    b1 = (ImageButton)findViewById(R.id.imageButton8);
                    b2 = (ImageButton)findViewById(R.id.imageButton10);
                    b3 = (ImageButton)findViewById(R.id.imageButton11);
                    b4 = (ImageButton)findViewById(R.id.imageButton12);
                    b5 = (ImageButton)findViewById(R.id.imageButton13);
                    b6 = (ImageButton)findViewById(R.id.imageButton14);
                    b7 = (ImageButton)findViewById(R.id.imageButton15);
                    b8 = (ImageButton)findViewById(R.id.imageButton16);
                    b9 = (ImageButton)findViewById(R.id.imageButton17);
                    b10 = (ImageButton)findViewById(R.id.imageButton18);
                    b11 = (ImageButton)findViewById(R.id.imageButton19);
                    b12 = (ImageButton)findViewById(R.id.imageButton20);
                    b13 = (ImageButton)findViewById(R.id.imageButton21);
                    b14 = (ImageButton)findViewById(R.id.imageButton22);
                    b15 = (ImageButton)findViewById(R.id.imageButton23);
                    b16 = (ImageButton)findViewById(R.id.imageButton24);
                    b17 = (ImageButton)findViewById(R.id.imageButton26);
                    b18 = (ImageButton)findViewById(R.id.imageButton27);
                    b1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent i = new Intent(getBaseContext(),Main4Activity.class);
                            startActivity(i);

                        }
                    });
                    b2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent i = new Intent(getBaseContext(),Main5Activity.class);
                            startActivity(i);
                        }
                    });
                    b3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent i = new Intent(getBaseContext(),Main6Activity.class);
                            startActivity(i);
                        }
                    });
                    b4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(getBaseContext(),Main7Activity.class);
                    startActivity(i);
                }
            });
            b5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(getBaseContext(),Main8Activity.class);
                    startActivity(i);
                }
            });
            b6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(getBaseContext(),Main9Activity.class);
                    startActivity(i);
                }
            });
            b7.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(getBaseContext(),Main10Activity.class);
                    startActivity(i);
                }
            });
            b8.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(getBaseContext(),Main11Activity.class);
                    startActivity(i);
                }
            });
            b9.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(getBaseContext(),Main12Activity.class);
                    startActivity(i);
                }
            });
            b10.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(getBaseContext(),Main13Activity.class);
                    startActivity(i);
                }
            });
            b11.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(getBaseContext(),Main14Activity.class);
                    startActivity(i);
                }
            });
            b12.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(getBaseContext(),Main15Activity.class);
                    startActivity(i);
                }
            });
            b13.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(getBaseContext(),Main16Activity.class);
                    startActivity(i);
                }
            });
            b14.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(getBaseContext(),Main17Activity.class);
                    startActivity(i);
                }
            });
            b15.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(getBaseContext(),Main18Activity.class);
                    startActivity(i);
                }
            });
            b16.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(getBaseContext(),Main19Activity.class);
                    startActivity(i);
                }
            });
            b17.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(getBaseContext(),Main20Activity.class);
                    startActivity(i);
                }
            });
            b18.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(getBaseContext(),Main21Activity.class);
                    startActivity(i);
                }
            });

                }
            }